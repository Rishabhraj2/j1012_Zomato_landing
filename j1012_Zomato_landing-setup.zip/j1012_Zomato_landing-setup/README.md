# This is my zomato landing page clone

## Done with first comit.

## set up created here for our appIn